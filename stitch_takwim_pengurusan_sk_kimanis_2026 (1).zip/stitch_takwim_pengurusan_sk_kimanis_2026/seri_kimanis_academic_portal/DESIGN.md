---
name: Seri Kimanis Academic Portal
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#434652'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#737783'
  outline-variant: '#c3c6d4'
  surface-tint: '#2b5bb5'
  primary: '#003178'
  on-primary: '#ffffff'
  primary-container: '#0d47a1'
  on-primary-container: '#a1bbff'
  inverse-primary: '#b0c6ff'
  secondary: '#006c47'
  on-secondary: '#ffffff'
  secondary-container: '#8af5be'
  on-secondary-container: '#00714b'
  tertiary: '#542a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#753d00'
  on-tertiary-container: '#ffa85e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00429c'
  secondary-fixed: '#8df7c1'
  secondary-fixed-dim: '#71dba6'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005235'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a prestigious, highly organized, and energetic digital environment tailored for primary school leadership, educators, and administrative staff. It balances Malaysian institutional gravitas with the accessible, uplifting warmth required of a thriving primary school community. 

### Target Audience & Emotional Intent
- **Primary Audience:** School administrators, teachers, headmasters (Guru Besar), and departmental leads managing annual educational operations, timetables, and academic performance.
- **Secondary Audience:** Parents and community stakeholders accessing school circulars, official calendars, and institutional charters.
- **Emotional Response:** Inspires civic pride, pedagogical clarity, orderliness, and optimism. The interface replaces cumbersome paper handbooks with an uncluttered, authoritative workspace.

### Design Movement: Modern Institutional & Tactile Card Hierarchy
Drawing from contemporary high-utility enterprise interfaces and modern editorial publication systems:
- **Pristine Base Canvas:** Generous pure-white and ultra-light neutral surfaces that mimic high-grade academic publication stock.
- **Structured Card Hierarchy:** Clear modularity through elevated cards, crisp division of academic terms, and distinct timeline markers.
- **Prestigious Accents:** Targeted application of royal blue and emerald green to denote institutional identity, anchored by warm amber gold for accolades, critical milestones, and national/state observances.

## Colors

The palette synthesizes Malaysian educational prestige with functional legibility.

### Palette Architecture
- **Primary (`#0D47A1` - Royal School Blue):** The core institutional identity color. Represents authority, commitment, and state educational governance. Used for primary navigation, major action buttons, main heading highlights, and active tab states.
- **Secondary (`#00875A` - Sabah Emerald Green):** Evokes vitality, nature, school spirit, and progress. Used for academic success indicators, completed curricular tasks, status tags, and curriculum-specific modules (Kurikulum).
- **Tertiary (`#D97706` - Warm Amber Gold):** Reflects excellence, official insignia, and royal educational honor. Reserved for critical calendar timelines, urgent notices, badges of merit, Kokurikulum highlights, and attention markers.
- **Neutral (`#1E293B` - Slate Core):** A deep slate tint providing contrast without the harshness of pure black. Drives high legibility across extensive administrative tables, body text, and structural dividers.

### Functional Surfaces & Backgrounds
- **Canvas Base:** `#F8FAFC` (Slate 50) for outer canvas framing; pure `#FFFFFF` for primary content cards, sidebars, and dialogue modules.
- **Borders & Dividers:** Subtle slate rules using `#E2E8F0` (Slate 200) preserve separation without visual clutter.

## Typography

The typographic hierarchy pairs **Plus Jakarta Sans** for structural and display headers with **Inter** for data grids, administrative rosters, and narrative body copy.

### Usage Rules
- **Headers & Display (`Plus Jakarta Sans`):** Selected for its friendly geometry, balanced aperture, and energetic contemporary finish. Ensures official Malay terminology (*Takwim Persekolahan*, *Jawatankuasa Pengurusan*, *Hal Ehwal Murid*) looks crisp and welcoming.
- **Body & Data (`Inter`):** Selected for neutral, utilitarian readability across densely formatted academic matrices, timetable lists, and staff directory records.
- **Micro-labels & Badges:** Use `label-sm` set to uppercase with increased letter-spacing (`0.05em`) to differentiate status indicators, academic week codes (e.g., `MINGGU 01`, `PENGGAL 1`), and committee tiers.

## Layout & Spacing

The portal layout adheres to a strict 12-column responsive fluid grid designed to display multi-tier institutional information without visual fatigue.

### Layout Model
- **Desktop (1024px+):** 12-column grid, `margin: 2rem`, `gutter: 1.5rem`. Layout maintains a sticky left navigation pillar (260px) alongside a dynamic content area optimized for multi-card metric grids and calendar splits.
- **Tablet (768px – 1023px):** 8-column grid, `margin: 1.5rem`, `gutter: 1rem`. Side navigation collapses into an accessible slide-over drawer; statistic cards reflow into a 2x2 grid.
- **Mobile (< 768px):** 4-column grid, `margin: 1rem`, `gutter: 1rem`. Multi-column calendar timelines stack sequentially with date stamps converted into horizontal anchor bars.

### Content Spacing Rhythm
- Compact internal card spacing (`space-md` / 16px) is enforced for data density, while major structural groupings (e.g., between the school KPI row and the upcoming weekly schedule) utilize `space-xl` (40px) to enforce clear topical separation.

## Elevation & Depth

Visual hierarchy uses clean surface separation combined with soft, daylight ambient shadows tinted with institutional slate tones.

### Elevation Levels
- **Level 0 (Flat Canvas):** The `#F8FAFC` background provides a soft foundation. Used for non-clickable page foundations.
- **Level 1 (Structural Cards & Data Panels):** Pure white `#FFFFFF` surface bordered by a crisp `1px` border of `#E2E8F0` and an ultra-subtle ambient drop shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.05)`.
- **Level 2 (Interactive Hover & Highlighted Cards):** Applied when hovering over calendar blocks, statistic cards, or task assignments: `0 8px 16px -4px rgba(13, 71, 161, 0.08), 0 4px 6px -2px rgba(15, 23, 42, 0.03)`. A minute blue tint signals elevation and focus.
- **Level 3 (Modals, Timetable Popovers & Drawers):** High-level administrative popups, teacher assignment modals, and floating action menus: `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`. Accompanied by a translucent slate overlay (`rgba(15, 23, 42, 0.4)` with `backdrop-filter: blur(4px)`).

## Shapes

The design uses a **Rounded** (Level 2) shape language to balance professional structure with approachability.

### Corner Radius System
- **Core Elements (Cards, Tables, Panels):** `rounded-lg` (16px / 1rem) for containment cards, modal windows, and calendar containers. Softens structural boundaries while remaining disciplined.
- **Interactive Controls (Buttons, Inputs, Selectors):** `rounded` (8px / 0.5rem) for form fields, action buttons, search bars, and pagination triggers.
- **Pill Exceptions (Badges & Status Tags):** Academic session indicators, status pills, and categorical taxonomy badges use `rounded-full` (9999px) for clean contrast against rectangular cards.

## Components

### Buttons
- **Primary (Royal Blue):** Background `#0D47A1`, text `#FFFFFF`, font `label-lg`. Hover: `#0A387E`. Active: `#072A5E`.
- **Secondary (Emerald Green):** Background `#00875A`, text `#FFFFFF`, font `label-lg`. Used for approving academic plans or confirming schedules. Hover: `#006E48`.
- **Tertiary / Outline:** Background `#FFFFFF`, border `1px solid #CBD5E1`, text `#1E293B`. Hover: `#F8FAFC`.
- **Destructive:** Background `#EF4444`, text `#FFFFFF`. For irreversible changes to records or schedules.

### Badges & Status Indicators
- **Academic Stream / Department Badges:** 
  - *Kurikulum:* Emerald background tint (`#E6F4EA`), text `#00875A`.
  - *Hal Ehwal Murid (HEM):* Blue background tint (`#EBF3FF`), text `#0D47A1`.
  - *Kokurikulum:* Amber background tint (`#FEF3C7`), text `#B45309`.
- **Status Pills:** Compact sizing (`label-sm`), uppercase text, full pill roundedness (`rounded-full`), padded `space-xs` vertically and `space-sm` horizontally.

### Statistic Cards (KPI & Enrollment)
- Structured white surface with a colored top accent strip (3px solid in Royal Blue, Emerald, or Gold).
- **Metric Figure:** Styled with `headline-lg` (`Plus Jakarta Sans`, 700 weight).
- **Metric Label:** Subdued slate label (`body-sm`) placed above or below the figure with an accompanying micro-icon reflecting student count, staff attendance, or teaching hours.

### Calendar & Timeline Elements
- **Timeline Rail:** Vertical line in `#E2E8F0` anchoring calendar dates.
- **Date Node:** Small round badge showing the day number in bold with the abbreviated month, flanked by colored dots indicating event type (School Holiday, Examination, Meeting).
- **Event Item Card:** Embedded inside the timeline with `border-l-4` color-coded by institutional category (Blue for School Administration, Emerald for Sports/Co-curriculum, Gold for State/National Holidays).

### Input Fields & Selectors
- Background `#FFFFFF`, border `1px solid #CBD5E1`, internal padding `space-sm space-md`.
- Focus state: Border transitions to `#0D47A1` with an ambient glow (`box-shadow: 0 0 0 3px rgba(13, 71, 161, 0.15)`).

### Checkboxes & Radios
- Size: `18px x 18px`. Border `1.5px solid #94A3B8`. Checked fill: `#0D47A1` with a crisp white check icon. Focus ring applies matching blue glow.